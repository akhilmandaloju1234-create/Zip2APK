# Zip2APK (final)

Turns a website ZIP (HTML/CSS/JS with an index.html) into an installable Android APK,
**entirely on your phone**. No server, no account, no internet, free.

Flow inside the app: **Choose ZIP -> (name, optional icon) -> Build APK -> Install / Download / Share.**

## 1. Get the app APK (one time)
Upload this whole ZIP to the build website (newly) as an Android Gradle project.
- Bundle identifier: anything you like, for example `com.yourname.zip2apk`.
- Download the finished APK and install it on your phone.

Backup way: put the contents of this ZIP in a GitHub repo (`.github/workflows/build.yml` is included),
run the workflow, and download the APK from the run's Artifacts.

## 2. Use it
1. Open Zip2APK, tap **Choose ZIP file**, pick your website ZIP.
2. Edit the app name, optionally pick an icon, tap **Build APK**.
3. Wait a few seconds. Then tap **Install** (Android asks once to allow installs from Zip2APK),
   or **Download to phone** (saved in Downloads), or **Share**.

## What goes in the ZIP
- `index.html` at the top, or inside one folder. Other files (CSS, JS, images, fonts) are included.
- Up to 100 MB ZIP, 60 MB per file.

## How it works (short)
The app copies its own APK, changes the package name and app name inside it, puts your website
into `assets/www/`, replaces the icon, aligns it and signs it with a key kept in your phone's
Android Keystore. The new app opens your site in a full-screen WebView.

## Honest limits
- Each new app gets its own package name made from its name (same name = update of the same app).
- APKs are signed with a key that lives on this phone: fine for your own devices and sharing APKs,
  not for Google Play. If you uninstall Zip2APK, the key is lost; apps built later cannot update
  apps built earlier (uninstall the old one first).
- Generated apps also carry the converter's code and the INTERNET / install permissions.
- Websites that need a server (PHP, Node) will not work; static sites and client-side apps do.
- Not tested on a real phone by the author of this package: if something fails, the app shows a message.
