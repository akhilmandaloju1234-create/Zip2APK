package org.zip2apk.converter.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Builds a new (still unsigned) APK from a template APK: swaps the manifest strings, replaces the
 * launcher icons and adds the website files under assets/www/.
 */
public final class ApkAssembler {
    /** Supplies launcher icon PNGs. */
    public interface IconSource {
        byte[] pngForSize(int px) throws IOException;
    }

    private static final Pattern ICON_PATH =
            Pattern.compile("^res/(mipmap|drawable)[a-z0-9-]*/ic_launcher\\.png$");
    private static final long INLINE_LIMIT = 1024 * 1024;
    private static final Set<String> TEXT_EXT = new HashSet<>();

    static {
        Collections.addAll(TEXT_EXT, "html", "htm", "css", "js", "mjs", "json", "svg", "txt", "xml", "map", "md",
                "csv", "webmanifest");
    }

    private ApkAssembler() {
    }

    public static void assemble(File templateApk, File webRoot, Map<String, String> manifestStrings,
                                IconSource icons, Set<String> extraIconPaths, File outUnsigned)
            throws IOException, ConvertException {
        try (ZipFile zip = new ZipFile(templateApk);
             AlignedZipWriter writer = new AlignedZipWriter(new FileOutputStream(outUnsigned))) {
            boolean sawManifest = false;
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (e.isDirectory() || name.startsWith("assets/www/")) {
                    continue;
                }
                if (isSignatureFile(name)) {
                    continue;
                }
                byte[] data = readAll(zip, e);
                if (name.equals("AndroidManifest.xml")) {
                    sawManifest = true;
                    writer.addDeflated(name, AxmlPatcher.replaceStrings(data, manifestStrings));
                } else if (name.equals("resources.arsc")) {
                    writer.addStored(name, data, 4);
                } else if (icons != null && (ICON_PATH.matcher(name).matches() || extraIconPaths.contains(name))) {
                    writer.addStored(name, icons.pngForSize(sizeForPath(name)), 4);
                } else if (name.endsWith(".so")) {
                    writer.addStored(name, data, 4096);
                } else if (e.getMethod() == ZipEntry.STORED) {
                    writer.addStored(name, data, 4);
                } else {
                    writer.addDeflated(name, data);
                }
            }
            if (!sawManifest) {
                throw new ConvertException("Template APK has no manifest.");
            }
            addWebFiles(writer, webRoot, webRoot, "assets/www/");
            writer.finish();
        }
    }

    private static void addWebFiles(AlignedZipWriter writer, File root, File dir, String prefix)
            throws IOException {
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        List<File> sorted = new ArrayList<>();
        Collections.addAll(sorted, children);
        Collections.sort(sorted);
        for (File f : sorted) {
            if (f.isDirectory()) {
                addWebFiles(writer, root, f, prefix);
                continue;
            }
            String rel = root.toURI().relativize(f.toURI()).getPath();
            String entryName = prefix + rel;
            if (writer.has(entryName)) {
                continue;
            }
            String ext = "";
            int dot = f.getName().lastIndexOf('.');
            if (dot >= 0) {
                ext = f.getName().substring(dot + 1).toLowerCase(Locale.ROOT);
            }
            if (f.length() <= INLINE_LIMIT && TEXT_EXT.contains(ext)) {
                writer.addDeflated(entryName, readFile(f));
            } else {
                writer.addStored(entryName, f, 4);
            }
        }
    }

    private static boolean isSignatureFile(String name) {
        if (!name.startsWith("META-INF/")) {
            return false;
        }
        String upper = name.toUpperCase(Locale.ROOT);
        return upper.equals("META-INF/MANIFEST.MF") || upper.endsWith(".SF") || upper.endsWith(".RSA")
                || upper.endsWith(".DSA") || upper.endsWith(".EC");
    }

    static int sizeForPath(String path) {
        if (path.contains("xxxhdpi")) return 192;
        if (path.contains("xxhdpi")) return 144;
        if (path.contains("xhdpi")) return 96;
        if (path.contains("hdpi")) return 72;
        if (path.contains("mdpi")) return 48;
        if (path.contains("ldpi")) return 36;
        return 192;
    }

    private static byte[] readAll(ZipFile zip, ZipEntry e) throws IOException {
        try (InputStream in = zip.getInputStream(e)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream((int) Math.max(1024, e.getSize()));
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        }
    }

    private static byte[] readFile(File f) throws IOException {
        try (InputStream in = new java.io.FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream((int) Math.max(1024, f.length()));
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        }
    }
}
