package org.zip2apk.converter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;

import org.zip2apk.converter.core.ApkAssembler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/** Creates launcher icons: either from the user's picture or a coloured letter. */
final class IconMaker implements ApkAssembler.IconSource {
    private final Bitmap source;
    private final String letter;
    private final int color;

    private IconMaker(Bitmap source, String letter, int color) {
        this.source = source;
        this.letter = letter;
        this.color = color;
    }

    static IconMaker fromUri(Context ctx, Uri uri) throws IOException {
        Bitmap b = decode(ctx, uri, 512);
        if (b == null) {
            throw new IOException("Could not read that image.");
        }
        return new IconMaker(b, null, 0);
    }

    static IconMaker forName(String name) {
        String t = name == null ? "" : name.trim();
        String letter = t.isEmpty() ? "A" : t.substring(0, t.offsetByCodePoints(0, 1)).toUpperCase(Locale.ROOT);
        float hue = (t.hashCode() & 0x7FFFFFFF) % 360;
        int color = Color.HSVToColor(new float[]{hue, 0.62f, 0.78f});
        return new IconMaker(null, letter, color);
    }

    static Bitmap decode(Context ctx, Uri uri, int maxSide) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) {
                return null;
            }
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) {
                return null;
            }
            return BitmapFactory.decodeStream(in, null, opts);
        }
    }

    @Override
    public byte[] pngForSize(int px) throws IOException {
        Bitmap bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        if (source != null) {
            int side = Math.min(source.getWidth(), source.getHeight());
            int left = (source.getWidth() - side) / 2;
            int top = (source.getHeight() - side) / 2;
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            canvas.drawBitmap(source, new Rect(left, top, left + side, top + side), new Rect(0, 0, px, px), p);
        } else {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(color);
            canvas.drawRoundRect(new RectF(0, 0, px, px), px * 0.22f, px * 0.22f, bg);
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(Color.WHITE);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextSize(px * 0.56f);
            float y = px / 2f - (t.descent() + t.ascent()) / 2f;
            canvas.drawText(letter, px / 2f, y, t);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
        bmp.recycle();
        return bos.toByteArray();
    }
}
