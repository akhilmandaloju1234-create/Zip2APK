package org.zip2apk.converter.core;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Safely unpacks a user ZIP and finds the folder that holds index.html. */
public final class ZipExtractor {
    public static final int MAX_FILES = 10000;
    public static final long MAX_FILE_BYTES = 60L * 1024 * 1024;
    public static final long MAX_TOTAL_BYTES = 150L * 1024 * 1024;

    public static final class Result {
        public final File webRoot;
        public final String suggestedName;
        public final int fileCount;
        public final long totalBytes;

        Result(File webRoot, String suggestedName, int fileCount, long totalBytes) {
            this.webRoot = webRoot;
            this.suggestedName = suggestedName;
            this.fileCount = fileCount;
            this.totalBytes = totalBytes;
        }
    }

    private ZipExtractor() {
    }

    public static Result extract(InputStream source, File destDir) throws IOException, ConvertException {
        if (!destDir.exists() && !destDir.mkdirs()) {
            throw new IOException("Cannot create work folder");
        }
        String destCanonical = destDir.getCanonicalPath() + File.separator;
        int files = 0;
        long total = 0;
        boolean sawAny = false;
        List<String> indexPaths = new ArrayList<>();

        try (ZipInputStream zin = new ZipInputStream(source, StandardCharsets.UTF_8)) {
            ZipEntry entry;
            byte[] buf = new byte[64 * 1024];
            while ((entry = zin.getNextEntry()) != null) {
                sawAny = true;
                String name = entry.getName().replace('\\', '/');
                if (entry.isDirectory()) {
                    continue;
                }
                if (name.startsWith("/") || name.matches("^[A-Za-z]:.*")) {
                    throw new ConvertException("This ZIP contains unsafe paths and was rejected.");
                }
                for (String part : name.split("/")) {
                    if (part.equals("..")) {
                        throw new ConvertException("This ZIP contains unsafe paths and was rejected.");
                    }
                }
                if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store") || name.endsWith("Thumbs.db")) {
                    continue;
                }
                files++;
                if (files > MAX_FILES) {
                    throw new ConvertException("This ZIP has too many files (limit " + MAX_FILES + ").");
                }
                File target = new File(destDir, name);
                String canonical = target.getCanonicalPath();
                if (!canonical.startsWith(destCanonical)) {
                    throw new ConvertException("This ZIP contains unsafe paths and was rejected.");
                }
                File parent = target.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) {
                    throw new IOException("Cannot create folder for " + name);
                }
                long size = 0;
                try (FileOutputStream fos = new FileOutputStream(target)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) {
                        size += n;
                        total += n;
                        if (size > MAX_FILE_BYTES) {
                            throw new ConvertException("A file inside the ZIP is larger than 60 MB.");
                        }
                        if (total > MAX_TOTAL_BYTES) {
                            throw new ConvertException("The ZIP is larger than 150 MB when unpacked.");
                        }
                        fos.write(buf, 0, n);
                    }
                }
                String lower = name.toLowerCase(Locale.ROOT);
                if (lower.equals("index.html") || lower.endsWith("/index.html")) {
                    indexPaths.add(name);
                }
            }
        }

        if (!sawAny) {
            throw new ConvertException("This file is not a valid ZIP, or it is empty.");
        }
        if (indexPaths.isEmpty()) {
            throw new ConvertException(
                    "No index.html found. Your ZIP needs an index.html file (at the top or inside one folder).");
        }

        String best = null;
        int bestDepth = Integer.MAX_VALUE;
        for (String p : indexPaths) {
            int depth = p.split("/").length;
            if (depth < bestDepth || (depth == bestDepth && p.length() < best.length())) {
                best = p;
                bestDepth = depth;
            }
        }
        File indexFile = new File(destDir, best);
        File webRoot = indexFile.getParentFile();
        return new Result(webRoot, readTitle(indexFile), files, total);
    }

    private static String readTitle(File html) {
        try (InputStream in = new java.io.FileInputStream(html)) {
            byte[] head = new byte[64 * 1024];
            int n = in.read(head);
            if (n <= 0) {
                return null;
            }
            String text = new String(head, 0, n, StandardCharsets.UTF_8);
            Matcher m = Pattern.compile("<title[^>]*>([^<]{1,80})</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL)
                    .matcher(text);
            if (m.find()) {
                String t = m.group(1).replaceAll("\\s+", " ").trim();
                return t.isEmpty() ? null : t;
            }
        } catch (IOException ignored) {
        }
        return null;
    }
}
