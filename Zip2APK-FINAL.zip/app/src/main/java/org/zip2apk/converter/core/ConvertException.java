package org.zip2apk.converter.core;

/** A problem the user can understand (bad ZIP, no index.html, ...). */
public class ConvertException extends Exception {
    public ConvertException(String message) {
        super(message);
    }

    public ConvertException(String message, Throwable cause) {
        super(message, cause);
    }
}
