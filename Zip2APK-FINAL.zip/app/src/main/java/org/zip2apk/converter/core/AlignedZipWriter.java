package org.zip2apk.converter.core;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/** Writes a ZIP/APK where STORED entries start on a 4-byte (or custom) boundary, like zipalign. */
public final class AlignedZipWriter implements Closeable {
    private static final int DOS_TIME = 0;
    private static final int DOS_DATE = ((2024 - 1980) << 9) | (1 << 5) | 1;

    private static final class Entry {
        byte[] name;
        int method;
        long crc;
        long csize;
        long usize;
        long offset;
    }

    private static final class Counting extends OutputStream {
        private final OutputStream out;
        long count;

        Counting(OutputStream out) {
            this.out = out;
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }

        @Override
        public void flush() throws IOException {
            out.flush();
        }

        @Override
        public void close() throws IOException {
            out.close();
        }
    }

    private final Counting out;
    private final List<Entry> entries = new ArrayList<>();
    private final Set<String> names = new HashSet<>();
    private boolean finished;

    public AlignedZipWriter(OutputStream stream) {
        this.out = new Counting(new BufferedOutputStream(stream, 64 * 1024));
    }

    public boolean has(String name) {
        return names.contains(name);
    }

    public void addDeflated(String name, byte[] data) throws IOException {
        Entry e = begin(name, 8);
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        Deflater d = new Deflater(9, true);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(64, data.length / 2));
        try {
            d.setInput(data);
            d.finish();
            byte[] buf = new byte[16 * 1024];
            while (!d.finished()) {
                int n = d.deflate(buf);
                bos.write(buf, 0, n);
            }
        } finally {
            d.end();
        }
        byte[] comp = bos.toByteArray();
        e.crc = crc.getValue();
        e.usize = data.length;
        e.csize = comp.length;
        writeLocalHeader(e, 0);
        out.write(comp);
    }

    public void addStored(String name, byte[] data, int align) throws IOException {
        Entry e = begin(name, 0);
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        e.crc = crc.getValue();
        e.usize = data.length;
        e.csize = data.length;
        writeLocalHeader(e, align);
        out.write(data);
    }

    public void addStored(String name, File file, int align) throws IOException {
        Entry e = begin(name, 0);
        CRC32 crc = new CRC32();
        long size = 0;
        byte[] buf = new byte[64 * 1024];
        try (InputStream in = new FileInputStream(file)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                crc.update(buf, 0, n);
                size += n;
            }
        }
        e.crc = crc.getValue();
        e.usize = size;
        e.csize = size;
        writeLocalHeader(e, align);
        long copied = 0;
        try (InputStream in = new FileInputStream(file)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                copied += n;
            }
        }
        if (copied != size) {
            throw new IOException("File changed while packing: " + name);
        }
    }

    private Entry begin(String name, int method) throws IOException {
        if (finished) {
            throw new IOException("Already finished");
        }
        if (!names.add(name)) {
            throw new IOException("Duplicate entry: " + name);
        }
        Entry e = new Entry();
        e.name = name.getBytes(StandardCharsets.UTF_8);
        if (e.name.length > 0xFFFF) {
            throw new IOException("Name too long");
        }
        e.method = method;
        e.offset = out.count;
        entries.add(e);
        return e;
    }

    private void writeLocalHeader(Entry e, int align) throws IOException {
        int pad = 0;
        if (e.method == 0 && align > 1) {
            long dataStart = out.count + 30 + e.name.length;
            pad = (int) ((align - (dataStart % align)) % align);
        }
        ByteBuffer h = ByteBuffer.allocate(30 + e.name.length + pad).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x04034b50);
        h.putShort((short) 20);
        h.putShort((short) 0x0800);
        h.putShort((short) e.method);
        h.putShort((short) DOS_TIME);
        h.putShort((short) DOS_DATE);
        h.putInt((int) e.crc);
        h.putInt((int) e.csize);
        h.putInt((int) e.usize);
        h.putShort((short) e.name.length);
        h.putShort((short) pad);
        h.put(e.name);
        out.write(h.array());
    }

    public void finish() throws IOException {
        if (finished) {
            return;
        }
        finished = true;
        long cdStart = out.count;
        for (Entry e : entries) {
            ByteBuffer h = ByteBuffer.allocate(46 + e.name.length).order(ByteOrder.LITTLE_ENDIAN);
            h.putInt(0x02014b50);
            h.putShort((short) 20);
            h.putShort((short) 20);
            h.putShort((short) 0x0800);
            h.putShort((short) e.method);
            h.putShort((short) DOS_TIME);
            h.putShort((short) DOS_DATE);
            h.putInt((int) e.crc);
            h.putInt((int) e.csize);
            h.putInt((int) e.usize);
            h.putShort((short) e.name.length);
            h.putShort((short) 0);
            h.putShort((short) 0);
            h.putShort((short) 0);
            h.putShort((short) 0);
            h.putInt(0);
            h.putInt((int) e.offset);
            h.put(e.name);
            out.write(h.array());
        }
        long cdSize = out.count - cdStart;
        if (entries.size() > 0xFFFF || out.count > 0xFFFFFFFFL) {
            throw new IOException("Archive too large");
        }
        ByteBuffer end = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN);
        end.putInt(0x06054b50);
        end.putShort((short) 0);
        end.putShort((short) 0);
        end.putShort((short) entries.size());
        end.putShort((short) entries.size());
        end.putInt((int) cdSize);
        end.putInt((int) cdStart);
        end.putShort((short) 0);
        out.write(end.array());
        out.flush();
    }

    @Override
    public void close() throws IOException {
        out.close();
    }
}
