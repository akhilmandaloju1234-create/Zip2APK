package org.zip2apk.converter;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.TypedValue;

import org.zip2apk.converter.core.ApkAssembler;
import org.zip2apk.converter.core.ConvertException;
import org.zip2apk.converter.core.ZipExtractor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** The whole ZIP -> APK pipeline. Runs on a background thread. */
final class Converter {
    /** The app label as written in this app's manifest; it is swapped for the new app's name. */
    static final String MANIFEST_LABEL = "Zip2APK";

    interface Progress {
        void step(int index, int total, String text);
    }

    static final class Result {
        final File apk;
        final String appName;
        final String packageName;
        final long sizeBytes;

        Result(File apk, String appName, String packageName, long sizeBytes) {
            this.apk = apk;
            this.appName = appName;
            this.packageName = packageName;
            this.sizeBytes = sizeBytes;
        }
    }

    private final Context ctx;

    Converter(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    Result convert(Uri zipUri, String requestedName, Uri iconUri, Progress progress) throws Exception {
        File work = new File(ctx.getCacheDir(), "work-" + System.currentTimeMillis());
        try {
            progress.step(1, 5, "Checking your ZIP");
            ZipExtractor.Result site;
            try (InputStream in = ctx.getContentResolver().openInputStream(zipUri)) {
                if (in == null) {
                    throw new ConvertException("Could not open the ZIP file.");
                }
                site = ZipExtractor.extract(in, new File(work, "site"));
            }

            String name = cleanName(requestedName);
            if (name.isEmpty()) {
                name = site.suggestedName != null ? cleanName(site.suggestedName) : "";
            }
            if (name.isEmpty()) {
                name = "My App";
            }
            String pkg = packageFor(name);

            progress.step(2, 5, "Preparing app files");
            ApplicationInfo ai = ctx.getApplicationInfo();
            if (ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0) {
                throw new ConvertException(
                        "This copy of Zip2APK was installed in several parts. Please install the single APK file.");
            }
            File template = new File(ai.sourceDir);

            Map<String, String> strings = new HashMap<>();
            strings.put(ctx.getPackageName(), pkg);
            strings.put(MANIFEST_LABEL, name);

            ApkAssembler.IconSource icons;
            if (iconUri != null) {
                try {
                    icons = IconMaker.fromUri(ctx, iconUri);
                } catch (IOException e) {
                    throw new ConvertException("Could not read the icon image. Choose another one.", e);
                }
            } else {
                icons = IconMaker.forName(name);
            }
            Set<String> extraIconPaths = new HashSet<>();
            try {
                TypedValue tv = new TypedValue();
                ctx.getResources().getValue(R.mipmap.ic_launcher, tv, true);
                if (tv.string != null) {
                    extraIconPaths.add(tv.string.toString());
                }
            } catch (Exception ignored) {
            }

            progress.step(3, 5, "Building your APK");
            File unsigned = new File(work, "unsigned.apk");
            ApkAssembler.assemble(template, site.webRoot, strings, icons, extraIconPaths, unsigned);

            progress.step(4, 5, "Signing");
            File outDir = new File(ctx.getFilesDir(), "apks");
            if (!outDir.exists() && !outDir.mkdirs()) {
                throw new IOException("Cannot create output folder.");
            }
            File out = new File(outDir, fileSlug(name) + ".apk");
            ApkSign.sign(unsigned, out);

            progress.step(5, 5, "Checking the result");
            PackageInfo info = ctx.getPackageManager()
                    .getPackageArchiveInfo(out.getPath(), PackageManager.GET_SIGNING_CERTIFICATES);
            if (info == null) {
                throw new ConvertException(
                        "The new APK could not be read by Android, so it was not offered for install.");
            }
            if (!pkg.equals(info.packageName)) {
                throw new ConvertException("The new APK has an unexpected package name.");
            }
            if (info.signingInfo == null || info.signingInfo.hasMultipleSigners()) {
                throw new ConvertException("The new APK is not signed correctly.");
            }
            return new Result(out, name, pkg, out.length());
        } finally {
            deleteRecursive(work);
        }
    }

    static String cleanName(String s) {
        if (s == null) {
            return "";
        }
        String t = s.replaceAll("\\p{Cntrl}", "").trim();
        if (t.length() > 30) {
            t = t.substring(0, 30).trim();
        }
        return t;
    }

    static String packageFor(String name) {
        String slug = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (slug.length() > 18) {
            slug = slug.substring(0, 18);
        }
        if (slug.isEmpty()) {
            slug = "app";
        }
        String hash = Integer.toHexString(name.hashCode() & 0xFFFF);
        return "com.zip2apk.w" + slug + hash;
    }

    static String fileSlug(String name) {
        String s = name.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return s.isEmpty() ? "app" : s;
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) {
            return;
        }
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                deleteRecursive(k);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
