package org.zip2apk.converter;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.InputFilter;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.zip2apk.converter.core.ConvertException;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_ZIP = 1;
    private static final int REQ_ICON = 2;

    private static final int PRIMARY = 0xFF5B2EE0;
    private static final int PRIMARY_SOFT = 0xFFEDE8FD;
    private static final int BG = 0xFFF6F5FB;
    private static final int TEXT = 0xFF1B1B22;
    private static final int MUTED = 0xFF6B6B78;
    private static final int ERROR = 0xFFB3261E;
    private static final int OK = 0xFF1E7B34;

    private enum Stage { PICK, READY, BUILDING, DONE, ERROR }

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private WebHost webHost;
    private boolean receiverRegistered;

    private Stage stage = Stage.PICK;
    private Uri zipUri;
    private String zipName = "";
    private long zipSize = -1;
    private Uri iconUri;
    private File builtApk;
    private String builtName = "";
    private String builtPackage = "";
    private Uri savedUri;

    private LinearLayout pickCard;
    private LinearLayout buildCard;
    private LinearLayout progressCard;
    private LinearLayout doneCard;
    private LinearLayout errorCard;
    private TextView tvZip;
    private TextView tvStatus;
    private TextView tvDoneInfo;
    private TextView tvError;
    private EditText etName;
    private ImageView ivIcon;
    private Button btnPick;

    private final BroadcastReceiver installReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
            if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                Intent confirm;
                if (Build.VERSION.SDK_INT >= 33) {
                    confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
                } else {
                    confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                }
                if (confirm != null) {
                    try {
                        startActivity(confirm);
                    } catch (Exception e) {
                        toast("Could not open the installer.");
                    }
                }
            } else if (status == PackageInstaller.STATUS_SUCCESS) {
                toast("Installed. Look for the new app on your home screen.");
            } else {
                String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                toast("Install did not finish" + (msg != null ? ": " + msg : "."));
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (WebHost.hasWebApp(this)) {
            webHost = new WebHost(this);
            setContentView(webHost.view());
            return;
        }
        buildUi();
        IntentFilter filter = new IntentFilter(Installer.ACTION_RESULT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(installReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(installReceiver, filter);
        }
        receiverRegistered = true;
        render();
    }

    // ---------------------------------------------------------------- UI

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) {
            g.setStroke(dp(1), stroke);
        }
        return g;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(20), dp(20), dp(20));
        l.setBackground(shape(Color.WHITE, 20, 0xFFE6E4F0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(16));
        l.setLayoutParams(lp);
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(16);
        b.setTextColor(primary ? Color.WHITE : PRIMARY);
        b.setBackground(shape(primary ? PRIMARY : PRIMARY_SOFT, 14, 0));
        b.setStateListAnimator(null);
        b.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(12), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Zip2APK", 30, TEXT, true);
        TextView sub = text("Upload. Wait. Install.", 16, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(24));
        root.addView(title);
        root.addView(sub);

        // Step 1: pick
        pickCard = card();
        pickCard.addView(text("1  Choose your website ZIP", 17, TEXT, true));
        tvZip = text("A ZIP with an index.html inside.", 14, MUTED, false);
        tvZip.setPadding(0, dp(6), 0, 0);
        pickCard.addView(tvZip);
        btnPick = button("Choose ZIP file", true);
        btnPick.setOnClickListener(v -> pickZip());
        pickCard.addView(btnPick);
        root.addView(pickCard);

        // Step 2: name + icon + build
        buildCard = card();
        buildCard.addView(text("2  Name your app", 17, TEXT, true));
        etName = new EditText(this);
        etName.setSingleLine(true);
        etName.setHint("App name");
        etName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(30)});
        etName.setTextColor(TEXT);
        etName.setBackground(shape(BG, 12, 0xFFD9D6E8));
        etName.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nameLp.setMargins(0, dp(10), 0, 0);
        buildCard.addView(etName, nameLp);

        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        iconRow.setPadding(0, dp(12), 0, 0);
        ivIcon = new ImageView(this);
        ivIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivIcon.setBackground(shape(PRIMARY_SOFT, 12, 0));
        iconRow.addView(ivIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        Button btnIcon = button("Choose icon (optional)", false);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        iconLp.setMargins(dp(12), 0, 0, 0);
        btnIcon.setLayoutParams(iconLp);
        btnIcon.setOnClickListener(v -> pickIcon());
        iconRow.addView(btnIcon);
        buildCard.addView(iconRow);

        Button btnBuild = button("Build APK", true);
        btnBuild.setOnClickListener(v -> startBuild());
        buildCard.addView(btnBuild);
        root.addView(buildCard);

        // Building
        progressCard = card();
        progressCard.setGravity(Gravity.CENTER_HORIZONTAL);
        ProgressBar bar = new ProgressBar(this);
        bar.setIndeterminate(true);
        progressCard.addView(bar, new LinearLayout.LayoutParams(dp(48), dp(48)));
        tvStatus = text("Working...", 16, TEXT, true);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, dp(12), 0, 0);
        progressCard.addView(tvStatus);
        TextView hint = text("This takes a few seconds. You can keep this screen open.", 13, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(6), 0, 0);
        progressCard.addView(hint);
        root.addView(progressCard);

        // Done
        doneCard = card();
        doneCard.addView(text("Your APK is ready", 20, OK, true));
        tvDoneInfo = text("", 14, MUTED, false);
        tvDoneInfo.setPadding(0, dp(6), 0, 0);
        doneCard.addView(tvDoneInfo);
        Button btnInstall = button("Install", true);
        btnInstall.setOnClickListener(v -> doInstall());
        doneCard.addView(btnInstall);
        Button btnSave = button("Download to phone", false);
        btnSave.setOnClickListener(v -> doSave(false));
        doneCard.addView(btnSave);
        Button btnShare = button("Share", false);
        btnShare.setOnClickListener(v -> doSave(true));
        doneCard.addView(btnShare);
        Button btnAgain = button("Convert another ZIP", false);
        btnAgain.setOnClickListener(v -> reset());
        doneCard.addView(btnAgain);
        root.addView(doneCard);

        // Error
        errorCard = card();
        errorCard.addView(text("That did not work", 20, ERROR, true));
        tvError = text("", 14, TEXT, false);
        tvError.setPadding(0, dp(8), 0, 0);
        errorCard.addView(tvError);
        Button btnRetry = button("Try again", true);
        btnRetry.setOnClickListener(v -> reset());
        errorCard.addView(btnRetry);
        root.addView(errorCard);

        setContentView(scroll);
    }

    private void render() {
        pickCard.setVisibility(stage == Stage.PICK || stage == Stage.READY ? View.VISIBLE : View.GONE);
        buildCard.setVisibility(stage == Stage.READY ? View.VISIBLE : View.GONE);
        progressCard.setVisibility(stage == Stage.BUILDING ? View.VISIBLE : View.GONE);
        doneCard.setVisibility(stage == Stage.DONE ? View.VISIBLE : View.GONE);
        errorCard.setVisibility(stage == Stage.ERROR ? View.VISIBLE : View.GONE);
        btnPick.setText(stage == Stage.READY ? "Choose a different ZIP" : "Choose ZIP file");
    }

    private void reset() {
        stage = Stage.PICK;
        zipUri = null;
        iconUri = null;
        builtApk = null;
        savedUri = null;
        ivIcon.setImageDrawable(null);
        tvZip.setText("A ZIP with an index.html inside.");
        render();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---------------------------------------------------------------- actions

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        startActivityForResult(i, REQ_ZIP);
    }

    private void pickIcon() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_ICON);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (webHost != null) {
            if (!webHost.onActivityResult(requestCode, resultCode, data)) {
                super.onActivityResult(requestCode, resultCode, data);
            }
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_ZIP) {
            readFileInfo(uri);
            if (zipSize > 100L * 1024 * 1024) {
                showError("That ZIP is larger than 100 MB. Please use a smaller one.");
                return;
            }
            zipUri = uri;
            String base = zipName.replaceAll("(?i)\\.zip$", "").replaceAll("[-_]+", " ").trim();
            etName.setText(base.isEmpty() ? "My App" : base);
            String size = zipSize >= 0 ? " (" + Formatter.formatShortFileSize(this, zipSize) + ")" : "";
            tvZip.setText(zipName + size);
            stage = Stage.READY;
            render();
        } else if (requestCode == REQ_ICON) {
            try {
                Bitmap preview = IconMaker.decode(this, uri, 96);
                if (preview == null) {
                    toast("Could not read that image.");
                    return;
                }
                iconUri = uri;
                ivIcon.setImageBitmap(preview);
            } catch (Exception e) {
                toast("Could not read that image.");
            }
        }
    }

    private void readFileInfo(Uri uri) {
        zipName = "project.zip";
        zipSize = -1;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0 && !c.isNull(ni)) {
                    zipName = c.getString(ni);
                }
                if (si >= 0 && !c.isNull(si)) {
                    zipSize = c.getLong(si);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void startBuild() {
        if (zipUri == null) {
            return;
        }
        final String name = Converter.cleanName(etName.getText().toString());
        final Uri zip = zipUri;
        final Uri icon = iconUri;
        stage = Stage.BUILDING;
        tvStatus.setText("Starting...");
        render();
        exec.execute(() -> {
            try {
                Converter.Result r = new Converter(MainActivity.this).convert(zip, name, icon,
                        (index, total, text) -> ui.post(() -> tvStatus.setText(text + " (" + index + "/" + total + ")")));
                ui.post(() -> {
                    builtApk = r.apk;
                    builtName = r.appName;
                    builtPackage = r.packageName;
                    savedUri = null;
                    tvDoneInfo.setText(r.appName + "  -  " + Formatter.formatShortFileSize(this, r.sizeBytes));
                    stage = Stage.DONE;
                    render();
                });
            } catch (ConvertException e) {
                ui.post(() -> showError(e.getMessage()));
            } catch (OutOfMemoryError e) {
                ui.post(() -> showError("The phone ran out of memory. Try a smaller ZIP."));
            } catch (Throwable t) {
                ui.post(() -> showError("Something went wrong: " + t.getClass().getSimpleName()
                        + (t.getMessage() != null ? " - " + t.getMessage() : "")));
            }
        });
    }

    private void showError(String message) {
        tvError.setText(message);
        stage = Stage.ERROR;
        if (pickCard != null) {
            render();
        }
    }

    private void doInstall() {
        if (builtApk == null || !builtApk.exists()) {
            toast("The APK is no longer available. Please convert again.");
            return;
        }
        try {
            if (!Installer.install(this, builtApk)) {
                toast("Allow installs from Zip2APK on the next screen, then come back and tap Install again.");
            }
        } catch (Exception e) {
            toast("Could not start the install: " + e.getMessage());
        }
    }

    private void doSave(final boolean thenShare) {
        if (builtApk == null) {
            return;
        }
        if (savedUri != null) {
            if (thenShare) {
                Installer.share(this, savedUri);
            } else {
                toast("Already saved in your Downloads folder.");
            }
            return;
        }
        final File apk = builtApk;
        final String fileName = Converter.fileSlug(builtName) + ".apk";
        exec.execute(() -> {
            try {
                Uri uri = Installer.saveToDownloads(MainActivity.this, apk, fileName);
                ui.post(() -> {
                    savedUri = uri;
                    toast("Saved to Downloads: " + fileName);
                    if (thenShare) {
                        Installer.share(MainActivity.this, uri);
                    }
                });
            } catch (Exception e) {
                ui.post(() -> toast("Could not save: " + e.getMessage()));
            }
        });
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onBackPressed() {
        if (webHost != null && webHost.goBack()) {
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webHost != null) {
            webHost.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webHost != null) {
            webHost.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiverRegistered) {
            unregisterReceiver(installReceiver);
        }
        if (webHost != null) {
            webHost.destroy();
        }
        exec.shutdown();
    }
}
