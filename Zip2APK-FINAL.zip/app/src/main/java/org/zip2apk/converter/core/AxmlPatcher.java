package org.zip2apk.converter.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Replaces whole strings inside the string pool of a compiled (binary) AndroidManifest.xml.
 * Every attribute that points at a replaced string changes with it, because attributes only
 * store the string's index. String indexes never change, so nothing else has to be touched.
 */
public final class AxmlPatcher {
    private static final int RES_XML_TYPE = 0x0003;
    private static final int RES_STRING_POOL_TYPE = 0x0001;
    private static final int UTF8_FLAG = 0x100;

    private AxmlPatcher() {
    }

    public static byte[] replaceStrings(byte[] in, Map<String, String> replacements) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);
        if (in.length < 40 || (b.getShort(0) & 0xFFFF) != RES_XML_TYPE) {
            throw new IOException("Not a compiled XML file");
        }
        int poolStart = 8;
        if ((b.getShort(poolStart) & 0xFFFF) != RES_STRING_POOL_TYPE) {
            throw new IOException("String pool not found");
        }
        int poolHeaderSize = b.getShort(poolStart + 2) & 0xFFFF;
        int poolSize = b.getInt(poolStart + 4);
        int stringCount = b.getInt(poolStart + 8);
        int styleCount = b.getInt(poolStart + 12);
        int flags = b.getInt(poolStart + 16);
        int stringsStart = b.getInt(poolStart + 20);
        int stylesStart = b.getInt(poolStart + 24);
        boolean utf8 = (flags & UTF8_FLAG) != 0;
        if (poolHeaderSize < 28 || poolSize <= 0 || poolStart + poolSize > in.length || stringCount < 0
                || styleCount < 0) {
            throw new IOException("Corrupt string pool");
        }

        int offsetsPos = poolStart + poolHeaderSize;
        int[] offsets = new int[stringCount];
        for (int i = 0; i < stringCount; i++) {
            offsets[i] = b.getInt(offsetsPos + 4 * i);
        }
        int styleOffsetsPos = offsetsPos + 4 * stringCount;

        String[] strings = new String[stringCount];
        for (int i = 0; i < stringCount; i++) {
            strings[i] = readString(b, poolStart + stringsStart + offsets[i], utf8);
        }

        boolean changed = false;
        for (int i = 0; i < stringCount; i++) {
            String repl = replacements.get(strings[i]);
            if (repl != null) {
                strings[i] = repl;
                changed = true;
            }
        }
        if (!changed) {
            return in;
        }

        // Re-encode all strings.
        ByteArrayOutputStream blob = new ByteArrayOutputStream();
        int[] newOffsets = new int[stringCount];
        for (int i = 0; i < stringCount; i++) {
            newOffsets[i] = blob.size();
            writeString(blob, strings[i], utf8);
        }
        while (blob.size() % 4 != 0) {
            blob.write(0);
        }

        // Style data is copied unchanged.
        byte[] styleData = new byte[0];
        if (styleCount > 0 && stylesStart > 0) {
            int from = poolStart + stylesStart;
            int to = poolStart + poolSize;
            styleData = new byte[to - from];
            System.arraycopy(in, from, styleData, 0, styleData.length);
        }

        int newHeaderSize = 28;
        int newStringsStart = newHeaderSize + 4 * stringCount + 4 * styleCount;
        int newStylesStart = styleCount > 0 ? newStringsStart + blob.size() : 0;
        int newPoolSize = newStringsStart + blob.size() + styleData.length;

        ByteBuffer pool = ByteBuffer.allocate(newPoolSize).order(ByteOrder.LITTLE_ENDIAN);
        pool.putShort((short) RES_STRING_POOL_TYPE);
        pool.putShort((short) newHeaderSize);
        pool.putInt(newPoolSize);
        pool.putInt(stringCount);
        pool.putInt(styleCount);
        pool.putInt(flags);
        pool.putInt(newStringsStart);
        pool.putInt(newStylesStart);
        for (int i = 0; i < stringCount; i++) {
            pool.putInt(newOffsets[i]);
        }
        for (int i = 0; i < styleCount; i++) {
            pool.putInt(b.getInt(styleOffsetsPos + 4 * i));
        }
        pool.put(blob.toByteArray());
        pool.put(styleData);

        int restStart = poolStart + poolSize;
        int restLen = in.length - restStart;
        ByteBuffer out = ByteBuffer.allocate(8 + newPoolSize + restLen).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) RES_XML_TYPE);
        out.putShort(b.getShort(2));
        out.putInt(8 + newPoolSize + restLen);
        out.put(pool.array());
        out.put(in, restStart, restLen);
        return out.array();
    }

    /** Returns all strings of the pool (used for self-checks). */
    public static String[] readStrings(byte[] in) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);
        int poolStart = 8;
        int poolHeaderSize = b.getShort(poolStart + 2) & 0xFFFF;
        int stringCount = b.getInt(poolStart + 8);
        int flags = b.getInt(poolStart + 16);
        int stringsStart = b.getInt(poolStart + 20);
        boolean utf8 = (flags & UTF8_FLAG) != 0;
        String[] out = new String[stringCount];
        for (int i = 0; i < stringCount; i++) {
            int off = b.getInt(poolStart + poolHeaderSize + 4 * i);
            out[i] = readString(b, poolStart + stringsStart + off, utf8);
        }
        return out;
    }

    private static String readString(ByteBuffer b, int pos, boolean utf8) throws IOException {
        if (pos < 0 || pos >= b.limit()) {
            throw new IOException("String offset out of range");
        }
        if (utf8) {
            int p = pos;
            int first = b.get(p++) & 0xFF;
            if ((first & 0x80) != 0) {
                p++;
            }
            int bl = b.get(p++) & 0xFF;
            if ((bl & 0x80) != 0) {
                bl = ((bl & 0x7F) << 8) | (b.get(p++) & 0xFF);
            }
            if (p + bl > b.limit()) {
                throw new IOException("String out of range");
            }
            byte[] raw = new byte[bl];
            for (int i = 0; i < bl; i++) {
                raw[i] = b.get(p + i);
            }
            return new String(raw, StandardCharsets.UTF_8);
        }
        int p = pos;
        int n = b.getShort(p) & 0xFFFF;
        p += 2;
        if ((n & 0x8000) != 0) {
            n = ((n & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
            p += 2;
        }
        if (p + 2 * n > b.limit()) {
            throw new IOException("String out of range");
        }
        char[] chars = new char[n];
        for (int i = 0; i < n; i++) {
            chars[i] = (char) (b.getShort(p + 2 * i) & 0xFFFF);
        }
        return new String(chars);
    }

    private static void writeString(ByteArrayOutputStream out, String s, boolean utf8) throws IOException {
        if (utf8) {
            byte[] raw = s.getBytes(StandardCharsets.UTF_8);
            if (s.length() > 0x7FFF || raw.length > 0x7FFF) {
                throw new IOException("String too long");
            }
            writeLen8(out, s.length());
            writeLen8(out, raw.length);
            out.write(raw);
            out.write(0);
        } else {
            if (s.length() > 0x7FFFFFFF) {
                throw new IOException("String too long");
            }
            if (s.length() > 0x7FFF) {
                int hi = (s.length() >> 16) | 0x8000;
                out.write(hi & 0xFF);
                out.write((hi >> 8) & 0xFF);
                out.write(s.length() & 0xFF);
                out.write((s.length() >> 8) & 0xFF);
            } else {
                out.write(s.length() & 0xFF);
                out.write((s.length() >> 8) & 0xFF);
            }
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                out.write(c & 0xFF);
                out.write((c >> 8) & 0xFF);
            }
            out.write(0);
            out.write(0);
        }
    }

    private static void writeLen8(ByteArrayOutputStream out, int len) {
        if (len > 0x7F) {
            out.write((len >> 8) | 0x80);
            out.write(len & 0xFF);
        } else {
            out.write(len);
        }
    }
}
