package org.zip2apk.converter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

/** Shows the website that was packed into assets/www/ (used by every APK this app creates). */
final class WebHost {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/";
    private static final int FILE_REQ = 4242;

    private final Activity activity;
    private final WebView web;
    private ValueCallback<Uri[]> chooser;

    static boolean hasWebApp(Context context) {
        try (InputStream in = context.getAssets().open("www/index.html")) {
            return in != null;
        } catch (IOException e) {
            return false;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    WebHost(Activity activity) {
        this.activity = activity;
        this.web = new WebView(activity);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!HOST.equals(uri.getHost())) {
                    return null;
                }
                return serveAsset(uri);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) {
                    return false;
                }
                try {
                    WebHost.this.activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (chooser != null) {
                    chooser.onReceiveValue(null);
                }
                chooser = callback;
                try {
                    WebHost.this.activity.startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl(START_URL);
    }

    View view() {
        return web;
    }

    boolean goBack() {
        if (web.canGoBack()) {
            web.goBack();
            return true;
        }
        return false;
    }

    boolean onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != FILE_REQ) {
            return false;
        }
        if (chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            chooser = null;
        }
        return true;
    }

    void onPause() {
        web.onPause();
    }

    void onResume() {
        web.onResume();
    }

    void destroy() {
        web.destroy();
    }

    private WebResourceResponse serveAsset(Uri uri) {
        String path = uri.getPath();
        if (path == null || path.isEmpty() || path.equals("/")) {
            path = "/index.html";
        }
        if (path.endsWith("/")) {
            path = path + "index.html";
        }
        String rel = path.substring(1);
        for (String part : rel.split("/")) {
            if (part.equals("..")) {
                return notFound();
            }
        }
        try {
            return open(rel);
        } catch (IOException first) {
            // Single-page apps: unknown paths without a file extension fall back to index.html.
            String last = rel.substring(rel.lastIndexOf('/') + 1);
            if (last.indexOf('.') < 0) {
                try {
                    return open("index.html");
                } catch (IOException ignored) {
                }
            }
            return notFound();
        }
    }

    private WebResourceResponse open(String rel) throws IOException {
        InputStream in = activity.getAssets().open("www/" + rel);
        String mime = mimeFor(rel);
        return new WebResourceResponse(mime, isText(mime) ? "UTF-8" : null, in);
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream("Not found".getBytes()));
    }

    private static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.equals("application/javascript") || mime.equals("application/json")
                || mime.equals("image/svg+xml") || mime.equals("application/manifest+json");
    }

    private static String mimeFor(String path) {
        int slash = path.lastIndexOf('/');
        int dot = path.lastIndexOf('.');
        if (dot < 0 || dot < slash) {
            return "application/octet-stream";
        }
        String ext = path.substring(dot + 1).toLowerCase(Locale.ROOT);
        switch (ext) {
            case "html":
            case "htm":
                return "text/html";
            case "js":
            case "mjs":
                return "application/javascript";
            case "css":
                return "text/css";
            case "json":
            case "map":
                return "application/json";
            case "svg":
                return "image/svg+xml";
            case "wasm":
                return "application/wasm";
            case "webmanifest":
                return "application/manifest+json";
            case "woff2":
                return "font/woff2";
            case "woff":
                return "font/woff";
            case "ttf":
                return "font/ttf";
            case "otf":
                return "font/otf";
            case "txt":
                return "text/plain";
            case "xml":
                return "text/xml";
            case "ico":
                return "image/x-icon";
            case "mp4":
                return "video/mp4";
            case "webm":
                return "video/webm";
            case "mp3":
                return "audio/mpeg";
            case "ogg":
                return "audio/ogg";
            case "wav":
                return "audio/wav";
            default:
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                return m != null ? m : "application/octet-stream";
        }
    }
}
